const notificationsData = {}

export default notificationsData
