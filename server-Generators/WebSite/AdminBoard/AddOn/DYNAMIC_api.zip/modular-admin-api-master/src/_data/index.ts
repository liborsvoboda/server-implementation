export default {
  init() {},
}
