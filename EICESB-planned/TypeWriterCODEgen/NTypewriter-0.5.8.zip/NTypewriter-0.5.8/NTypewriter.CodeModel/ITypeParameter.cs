﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NTypewriter.CodeModel
{
    /// <summary>
    /// Represents a generic type parameter 
    /// </summary>
    public interface ITypeParameter
    {
    }
}