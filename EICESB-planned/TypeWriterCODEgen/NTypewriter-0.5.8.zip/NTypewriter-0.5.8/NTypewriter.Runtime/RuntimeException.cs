﻿using System;

namespace NTypewriter.Runtime
{
    public class RuntimeException : Exception
    {
        public RuntimeException(string message) : base(message)
        {
        }
    }
}