﻿namespace NTypewriter
{
    public static class VariableNames
    {
        public static readonly string CustomFunctions = "Custom";
        public static readonly string Data = "data";
        public static readonly string Config = "config";
        public static readonly string Env = "env";
    }
}