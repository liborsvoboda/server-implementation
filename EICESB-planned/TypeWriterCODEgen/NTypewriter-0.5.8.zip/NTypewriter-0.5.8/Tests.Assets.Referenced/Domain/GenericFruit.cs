﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tests.Assets.Referenced.Domain
{
    class GenericFruit<T> where T : Fruit
    {
    }
}
