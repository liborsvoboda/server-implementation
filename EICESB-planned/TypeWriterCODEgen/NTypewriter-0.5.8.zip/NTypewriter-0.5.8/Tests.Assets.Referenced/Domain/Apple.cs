﻿using System;

namespace Tests.Assets.Referenced.Domain
{
    class Apple : Fruit
    {
    }
}
