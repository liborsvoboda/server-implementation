﻿namespace Tests.Assets.WebApi.Controllers
{
    public class Paggination
    {
        public int Page { get; set; }
        public int Limit { get; set; }
    }
}
