﻿module App { 
    export class OrderModel {
        public date: Date;
    }
}