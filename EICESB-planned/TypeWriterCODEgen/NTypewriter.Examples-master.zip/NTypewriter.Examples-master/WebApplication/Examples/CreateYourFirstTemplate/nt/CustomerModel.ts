﻿module App { 
    export class CustomerModel {
        public id: number;
        public name: string;
        public orders: OrderModel[];
    }
}