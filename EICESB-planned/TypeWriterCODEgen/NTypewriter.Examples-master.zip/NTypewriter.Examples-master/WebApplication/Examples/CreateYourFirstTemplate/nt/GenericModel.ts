﻿module App { 
    export class GenericModel {
        public genericProp: T;
    }
}