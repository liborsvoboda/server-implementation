﻿module App { 
    export class WeatherForecastModel {
        public date: Date;
        public temperatureC: number;
        public temperatureF: number;
        public summary: string;
    }
}