﻿module Models {  

    export interface GenericModel<T> {
        genericProp: T;
    }
}