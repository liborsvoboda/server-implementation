﻿module Models {  

    export interface OrderModel {
        date: Date;
    }
}