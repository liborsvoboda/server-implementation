﻿module Models {  

    export interface WeatherForecastModel {
        date: Date;
        temperatureC: number;
        temperatureF: number;
        summary: string;
    }
}