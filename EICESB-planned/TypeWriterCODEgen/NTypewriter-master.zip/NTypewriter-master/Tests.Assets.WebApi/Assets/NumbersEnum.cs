﻿namespace Tests.Assets.WebApi.Controllers
{
    public enum NumbersEnum 
    {
        Five,
        Seven,
    }
}
