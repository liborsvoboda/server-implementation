﻿namespace Tests.Assets.WebApi.Controllers
{
    public class InputDTO
    {

    }
}
