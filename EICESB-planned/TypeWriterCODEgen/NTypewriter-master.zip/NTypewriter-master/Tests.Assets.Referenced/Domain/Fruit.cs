﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tests.Assets.Referenced.Domain
{
    abstract class Fruit
    {
    }
}
