﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tests.Assets.Referenced.Domain
{
    class Orange : Fruit
    {
    }
}
