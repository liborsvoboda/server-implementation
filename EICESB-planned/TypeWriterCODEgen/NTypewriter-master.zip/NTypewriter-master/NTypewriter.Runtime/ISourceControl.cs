﻿namespace NTypewriter.Runtime
{
    public interface ISourceControl
    {
        void Checkout(string filePath);
    }
}